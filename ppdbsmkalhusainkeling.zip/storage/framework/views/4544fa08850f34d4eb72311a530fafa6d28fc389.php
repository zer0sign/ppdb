<?php echo $__env->make('layouts.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
</style>
<div class="container" style="height: 56%">
    <div class="card text-center" style="margin-left:10%; margin-right: 10%">
        <div class="card-header">
          Cek Status Calon Peserta Didik Baru
        </div>
        <div class="card-body" >
          
            <form class="form" method="GET" action="<?php echo e(route('status')); ?>" style="display: flex; justify-content: center">
                <?php echo csrf_field(); ?>
                <input class="form-control mr-sm-2" type="search" placeholder="ID Pendaftar" aria-label="Search" name="id_siswa" required style="width: 50%;">
                <button id="btn-cari" class="btn btn-primary" type="submit">Search</button>
            </form>
        </div>
      </div>

</div>

<?php echo $__env->make('layouts.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zerosign/Desktop/dev/laravel/ppdb/resources/views/cekStatus.blade.php ENDPATH**/ ?>