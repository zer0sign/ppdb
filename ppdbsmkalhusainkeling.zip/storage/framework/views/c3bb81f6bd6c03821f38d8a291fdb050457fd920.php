<?php echo $__env->make('layouts.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($i->status == null): ?>
<div class="container" style="display: flex; justify-content: center; margin-top: 6%">
    <div class="card text-white bg-secondary mb-3" style="max-width: 18rem;">
        <div class="card-header">Status Pendaftaran</div>
        <div class="card-body">
        <h5 class="card-title"><b>ID : </b><?php echo e($i->id_siswa); ?></h5>
        <p class="card-text"><b>Jurusan : </b><?php echo e($i->jurusan); ?></p>
        <p class="card-text"><b>Nama :</b><?php echo e($i->nama); ?></p>
        <p class="card-text">Anda <b> Belum diverifikasi</b>,Silahkan Tunggu, proses Verifikasi, jika ada Pertanyaan silahkan Hubungi <b> 085290506533</b></p>
        </div>
    </div>
</div>

<?php else: ?>
<div class="container" style="display: flex; justify-content: center; margin-top: 6%">
    <div class="card text-white bg-info mb-3" style="max-width: 18rem;">
        <div class="card-header">Status Pendaftaran</div>
        <div class="card-body">
        <h5 class="card-title"><b>ID : </b><?php echo e($i->id_siswa); ?></h5>
        <p class="card-text"><b>Jurusan : </b><?php echo e($i->jurusan); ?></p>
        <p class="card-text"><b>Nama :</b><?php echo e($i->nama); ?></p>
        <p class="card-text">Anda Telah diverifikasi, dan <b> Diterima </b> Sebagai Siswa SMK AL HUSAIN KELING</p>
        </div>
    </div>
</div>

<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php echo $__env->make('layouts.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zerosign/Desktop/dev/laravel/ppdb/resources/views/status.blade.php ENDPATH**/ ?>