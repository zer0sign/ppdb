<?php echo $__env->make('layouts.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
.card-body{
}
</style>
<div class="container">
<div class="card">
    <div class="card-header">
        <div class="logoname" style="display:flex">
            <div class="logo">
            <img id="nav" src="<?php echo e(URL::asset('/img/assets/logo.png')); ?>" width="50" height="50" class="d-inline-block align-top" alt="" loading="lazy">
            </div>
            <div class="name" style="margin-left: 1%; margin-top: 0.3%">
            Pendaftaran
            <br>
            <b> SMK AL HUSAIN KELING</b>
            </div>
        </div>
    </div>
    <div class="card-body">
        <b><h5 style="text-align:center;">Kartu Pendaftaran Siswa Baru SMK Al HUSAIN Keling</h5></b>
        <br>
        <?php $__currentLoopData = $dataSiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p><b>ID Pendaftaran            : </b><?php echo e($siswa->id_siswa); ?></p>
        <p><b>Jurusan        : </b><?php echo e($siswa->jurusan); ?></p>
        <p><b>Nama           : </b><?php echo e($siswa->nama); ?></p>
        <p><b>Jenis Kelamin  : </b><?php echo e($siswa->jenis_kelamin); ?></p>
        <p><b>Agama          : </b><?php echo e($siswa->agama); ?></p>
        <p><b>Asal Sekolah   : </b><?php echo e($siswa->asal_sekolah); ?></p>
        <p><b>Nomor HP       : </b><?php echo e($siswa->nomor_hp); ?></p>
        
        <div class="container1" style="display:flex; flex-wrap:wrap; justify-content:space-between; align-items:center;">
            <div class="bag1" style="font-size:0.8em">
                <p>
                <b>Panduan</b><br>
1. Setelah selasai download, silahkan Cetak Kartu Ini
<br>
2. Bawa Kartu ini ke SMK AL Husain Keling
<br>
3. Lalu Konfirmasi Pendaftaran ke pihak PPDB SMK AL HUSAIN Keling
                </p>
            </div>
            <div class="clear">

            </div>
            <div class="bag2">
                <img width="150px" src="<?php echo e(url('/img/foto_siswa/' . $siswa->foto_siswa)); ?>">
            </div>
        </div>

    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>





<br>
<div class="download" style="text-align:center">
<a href="<?php echo e(route('cetakPdf')); ?>" class="btn btn-primary btn-lg active" role="button" aria-pressed="true">Download Formulir</a>
</div>
</div>

<?php echo $__env->make('layouts.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/zerosign/Desktop/dev/laravel/ppdb/resources/views/simpan.blade.php ENDPATH**/ ?>